package cn.HRefAligner;

import java.util.List;

import cn.ykp.hdf5.MyBReader;
import cn.ykp.hdf5.MyThread;


//Function: Compare Sam files with the HDF5 reference genome by Multithread
public class Example1 {


	public static void main(String[] args) throws Exception {
 
		//Example one:
		/**
		 * 	Find different SNPs of SAM by HDF5 Reference on More Threads 
		 *	parameters
		 *  1 file Path for .SAM 
		 *  2 Number of threads 
		 *  3 Number of comparison
		 */
		
		List<List<String>> list0=MyBReader.reader("D:\\demo_data\\demo.sam",5,100);
		//List<List<String>> list0=MyBReader.reader("/home/demo_data/demo.sam",5,100);
		//List<List<String>> list0=MyBReader.reader("D:\\demo_data\\demo.sam",5);		
		for(int i=0;i<list0.size();i++){
			MyThread myThread=new MyThread(list0.get(i),"D:\\demo_data\\demo.h5");
			//MyThread myThread=new MyThread(list0.get(i),"/home/demo_data/demo.h5");
			myThread.start();
			
		}
	
		MyBReader.CompletionThreed();
	  
		//on windows
			List<String> listInfo0=MyBReader.readTempWX();
		//on Linux
		//List<String> listInfo=MyBReader.readTempLinux();
		
		System.out.println(listInfo0.size());
		System.out.println(listInfo0.get(0));
		

	}

}
