package cn.HRefAligner;

import java.util.ArrayList;
import java.util.List;

import cn.ykp.hdf5.BatchQuery;
import cn.ykp.hdf5.HDF5Convert;
import cn.ykp.hdf5.MyBReader;
import cn.ykp.hdf5.Select;
//Function: HDF5 operation code
public class Main {

	//The execution steps remove comments, And the other steps of comments
	//Please note that different operating system access path settings
	public static void main(String[] args) throws Exception {
		/**
		 * Function one
	     * parameters
		 * 1 Reference genome of fasta format file
		 * 2 Conversion Reference genome of HDFf format file
		 */
		 
		HDF5Convert hDF5Convert=new HDF5Convert();
		hDF5Convert.hdf5Conert("D:\\demo_data\\demo.fasta", "D:\\demo_data\\demo.h5");
		//hDF5Convert.hdf5Conert("/home/demo_data/demo.fasta", "/home/demo_data/demo.h5"); 
		
		/**
		 * Function two
		 * parameters
		 * 1 Reference genome of HDFf format file
		 * 2 ChromosomeName
		 * 3 Start position
		 * 4 End position
		 */
	
		/*
			Select s=new Select();
			String str=s.selectFromHDF5("D:\\demo_data\\demo.h5", "Chr1", 48912, 1000);
			//String str=s.selectFromHDF5("/home/demo_data/demo.h5", "Chr1", 48912, 1000);
			System.out.println(str);
			System.out.println(str.length());
		*/	
		
		
		/**
		 * Function three
		 * Finding of More Threads for HDF5 Reference
		 * parameters
		 * 1 Reference genome of HDFf format file
		 * 2 ChromosomeName
		 * 3 Start position
		 * 4 End position
		 */
			
		
		/*
		BatchQuery batchQuery=new BatchQuery("D:\\demo_data\\demo.h5");		
	    //BatchQuery batchQuery=new BatchQuery("/home/demo_data/demo.h5");	
		List<String>  list=new ArrayList<String>();
		list.add("Chr1,148912,2000");
		list.add("Chr2,148912,2000");
		list.add("Chr3,148912,2000");
		list.add("Chr4,148912,2000");
		list.add("Chr5,148912,2000");		
		//list.add(.......)
		
		batchQuery.batchQuery(list);
		
		
		MyBReader.CompletionThreed();
				
		List<String> listInfo=MyBReader.readTempWXPool();
		System.out.println(listInfo.get(0));
		*/
		
		//on Linux
		//List<String> listInfo=MyBReader.readTempLinuxPool();
		//System.out.println(listInfo.get(0));	
		
			
	}

}
