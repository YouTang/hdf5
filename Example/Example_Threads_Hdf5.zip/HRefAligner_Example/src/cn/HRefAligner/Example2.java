package cn.HRefAligner;

import cn.ykp.Operation;
//Function (calling SNP): Main alignment differential loci
public class Example2 {
	//The execution steps remove comments, And the other steps of comments
	//Please note that different operating system access path settings
	public static void main(String[] args) throws Exception {
		
		/**
		 * First step operation 
		 * parameters
		 * 1 Reference genome of fasta format file
		 * 2 Conversion Reference genome of HDFf format Path
		 */
		
		Operation operation=new Operation();
		operation.converHDF5("D:\\demo_data\\zj.fsa", "D:\\demo_data\\");
		//operation.converHDF5("/home/demo_data/zj.fsa", "/home/demo_data/");
		
		/**
		 * The second step 
		 * Find different SNPs of SAM by HDF5 Reference on ChromosomeName
		 * parameters
		 * 1 file Path for .SAM 
		 * 2 Generate ChromosomeName file Path
		 * 3 Reference genome of HDFf format file
		 * 4 Grading standard in .SAM
		 */
		
		/*
		Operation operation=new Operation();
		operation.firstOperation("D:\\demo_data\\sam", "D:\\demo_data\\HDF5\\ChromosomeName.txt", "D:\\demo_data\\HDF5\\zj.h5", 25);
		//operation.firstOperation("/home/demo_data/sam", "/home/demo_data/HDF5/ChromosomeName.txt", "/home/demo_data/HDF5/zj.h5", 25);
		*/
		
		/**
		 * The Third step
		 * Integrated different SNPs
		 * parameters
		 * 1 different SNPs files path by ChromosomeName Decomposition
		 * 2 Integrated different SNPs file Path
		 */
		
		/*
		Operation operation=new Operation();
		operation.pretreatment("D:\\demo_data\\HDF5\\SourceData\\","D:\\demo_data\\HDF5\\SourceData2");
		//operation.pretreatment("/home/demo_data/HDF5/SourceData/", "/home/demo_data/HDF5/SourceData2");
	 */
	}
}
